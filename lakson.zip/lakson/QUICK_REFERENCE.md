# Lakson Shop - Clean Code Quick Reference

## Architecture Overview

```
┌─────────────────────────────────────────┐
│            UI Layer (Screens)           │
│  ┌──────────────┬──────────────────┐    │
│  │  LoginPage   │  RegisterPage    │    │
│  └──────────────┴──────────────────┘    │
│  ┌──────────────┬──────────────────┐    │
│  │ HomeScreen   │  CartScreen      │    │
│  └──────────────┴──────────────────┘    │
└─────────────────────────────────────────┘
              ↓ uses ↓
┌─────────────────────────────────────────┐
│       Provider Layer (State Mgmt)       │
│  ┌──────────────┬──────────────────┐    │
│  │ AuthProvider │ CartProvider     │    │
│  └──────────────┴──────────────────┘    │
└─────────────────────────────────────────┘
              ↓ calls ↓
┌─────────────────────────────────────────┐
│       Service Layer (API & Logic)       │
│  ┌──────────────┬──────────────────┐    │
│  │ AuthService  │  ApiService      │    │
│  └──────────────┴──────────────────┘    │
└─────────────────────────────────────────┘
              ↓ uses ↓
┌─────────────────────────────────────────┐
│        Data Layer (Models & Storage)    │
│  ┌──────────────┬──────────────────┐    │
│  │   Models     │ SharedPreferences│    │
│  └──────────────┴──────────────────┘    │
└─────────────────────────────────────────┘
```

## Service Usage Guide

### AuthService - Authentication Operations

**Login**:
```dart
final result = await AuthService.login(
  'user@example.com',
  'password123'
);

if (result['success']) {
  // Token saved automatically to SharedPreferences
  String token = result['token'];
  Map<String, dynamic> user = result['user'];
}
```

**Register**:
```dart
final result = await AuthService.register(
  lastName: 'Doe',
  firstName: 'John',
  age: '25',
  email: 'john@example.com',
  password: 'password123',
  passwordConfirmation: 'password123',
);

if (result['success']) {
  // Token saved automatically
  // Navigate to home
}
```

**Logout**:
```dart
await AuthService.logout();
// Clears token from SharedPreferences
```

### ApiService - Product & Order Operations

**Get Products**:
```dart
final prefs = await SharedPreferences.getInstance();
final token = prefs.getString('token') ?? '';

final products = await ApiService.getProducts(token: token);
```

**Place Order**:
```dart
final productIds = [1, 2, 3]; // Product IDs to order

final result = await ApiService.placeOrder(productIds);

if (result['success']) {
  // Order placed successfully
  String message = result['message'];
}
```

## Provider Usage Guide

### AuthProvider - Authentication State

**Access in Build Method**:
```dart
// Watch for changes
final auth = context.watch<AuthProvider>();
bool isLoggedIn = auth.isLoggedin;
Map<String, dynamic>? user = auth.user;

// Listen only (no rebuild)
Provider.of<AuthProvider>(context, listen: false)
```

**Methods**:
```dart
// Login
await Provider.of<AuthProvider>(context, listen: false)
  .login('email', 'password');

// Register
await Provider.of<AuthProvider>(context, listen: false)
  .register(
    name: 'John Doe',
    email: 'john@example.com',
    phone: '03001234567',
    address: 'Some address',
    password: 'pass123',
    passwordConfirmation: 'pass123',
  );

// Logout
await Provider.of<AuthProvider>(context, listen: false).logout();
```

### CartProvider - Shopping Cart State

**Watch Cart Items**:
```dart
final cart = context.watch<CartProvider>();
List<CartItem> items = cart.cartItems;
double total = cart.totalPrice;
```

**Methods**:
```dart
// Add item
cart.addToCart(product);

// Remove item
cart.removeFromCart(productId);

// Clear cart
cart.clearCart();
```

## Common Patterns

### Handle API Errors

```dart
try {
  final result = await AuthService.login(email, password);
  
  if (result['success'] == true) {
    // Success - navigate
  } else {
    // Show error
    showError(result['message'] ?? 'Operation failed');
  }
} catch (e) {
  showError('Network error: ${e.toString()}');
}
```

### Show Loading State

```dart
bool _isLoading = false;

setState(() => _isLoading = true);

try {
  // API call
} finally {
  if (mounted) setState(() => _isLoading = false);
}

// In UI
_isLoading
  ? CircularProgressIndicator()
  : ElevatedButton(onPressed: _handleAction)
```

### Show Error Messages

```dart
String? _errorMessage;

if (_errorMessage != null)
  Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Colors.red.shade100,
      border: Border.all(color: Colors.red),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Text(
      _errorMessage!,
      style: TextStyle(color: Colors.red.shade700),
    ),
  )
```

### Navigate After Authentication

```dart
if (result['success'] == true) {
  Navigator.pushReplacement(
    context,
    MaterialPageRoute(builder: (_) => const HomeScreen()),
  );
}
```

## Validation Rules

### Name Field
- Only letters and spaces allowed
- Example: "John Doe" ✅, "John123" ❌

### Email Field
- Must contain @ symbol
- Example: "user@example.com" ✅

### Phone Field
- Exactly 11 digits
- Example: "03001234567" ✅

### Password
- Minimum 6 characters
- Example: "pass123" ✅, "pass1" ❌

### Age Field
- Must be numeric
- Example: "25" ✅, "twenty-five" ❌

## Important Notes

1. **Token Storage**: Automatically handled by AuthService
   - Stored in SharedPreferences after login/register
   - Cleared on logout
   - Retrieved for API calls

2. **Bearer Token**: All API requests include
   ```
   Authorization: Bearer $token
   Content-Type: application/json
   ```

3. **Error Responses**: Handle both 422 (validation) and other errors
   - Validation errors have `errors` field with field-specific messages
   - Other errors have `message` field

4. **Network Requests**: Always use try-catch for network calls

5. **State Updates**: Use `if (mounted)` before setState after async operations

## Troubleshooting

### Issue: "No token" or 401 Unauthorized
**Solution**: Ensure user is logged in and token is stored
```dart
final prefs = await SharedPreferences.getInstance();
final token = prefs.getString('token');
print('Token: $token'); // Debug
```

### Issue: Navigation not working
**Solution**: Ensure `mounted` check is done
```dart
if (!mounted) return;
Navigator.pushReplacement(...);
```

### Issue: Form validation errors not showing
**Solution**: Update `_errorMessage` state properly
```dart
setState(() => _errorMessage = 'Error message');
```

### Issue: Loading indicator not showing
**Solution**: Ensure widget rebuilds on state change
```dart
setState(() => _isLoading = true);
// Do API call
setState(() => _isLoading = false);
```

---

**For more details, see REFACTORING_SUMMARY.md**
