package com.example.lakson

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
