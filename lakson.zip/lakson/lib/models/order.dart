class Order {
  final List<int> productIds;
  final String paymentMethod;

  Order({required this.productIds, required this.paymentMethod});

  Map<String, dynamic> toJson() {
    return {
      'product_ids': productIds,
      'payment_method': paymentMethod, // COD only
    };
  }
}
