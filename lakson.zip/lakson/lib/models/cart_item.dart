import 'package:lakson/models/product.dart';

class CartItem {
  final Product product;
  final int quantity;

  CartItem({required this.product, required this.quantity});

  double get totalPrice => product.price * quantity;

  Map<String, dynamic> toJson() {
    return {'product_id': product.id, 'quantity': quantity};
  }
}
