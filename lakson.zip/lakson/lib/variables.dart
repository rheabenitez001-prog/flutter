// variables.dart

const String baseUrl = "http://127.0.0.0:8000/api";
