import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthProvider extends ChangeNotifier {
  bool _isLoggedin = false;
  Map<String, dynamic>? _user;

  bool get isLoggedin => _isLoggedin;
  Map<String, dynamic>? get user => _user;

  AuthProvider() {
    _checkLoginStatus();
  }

  /// Check if user is already logged in on app startup
  Future<void> _checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    _isLoggedin = token != null;
    notifyListeners();
  }

  /// Login with email and password
  Future<Map<String, dynamic>> login(String email, String password) async {
    final result = await AuthService.login(email, password);

    if (result['success'] == true) {
      _isLoggedin = true;
      _user = result['user'];
      notifyListeners();
    }

    return result;
  }

  /// Register new user
  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String phone,
    required String address,
    required String password,
    required String passwordConfirmation,
  }) async {
    final result = await AuthService.register(
      name: name,
      email: email,
      phone: phone,
      address: address,
      password: password,
      passwordConfirmation: passwordConfirmation,
    );

    if (result['success'] == true) {
      _isLoggedin = true;
      _user = result['user'];
      notifyListeners();
    }

    return result;
  }

  /// Logout user and clear stored data
  Future<void> logout() async {
    await AuthService.logout();
    _isLoggedin = false;
    _user = null;
    notifyListeners();
  }
}
