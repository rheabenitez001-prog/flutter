import 'package:flutter/material.dart';
import 'package:lakson/models/product.dart';
import 'package:lakson/models/cart_item.dart';

class CartProvider extends ChangeNotifier {
  final List<CartItem> _cartItems = [];

  List<CartItem> get cartItems => _cartItems;

  void addToCart(Product product) {
    _cartItems.add(CartItem(product: product, quantity: 1));
    notifyListeners();
  }

  void removeFromCart(Product product) {
    _cartItems.removeWhere((item) => item.product.id == product.id);
    notifyListeners();
  }

  double get totalPrice {
    return _cartItems.fold(0.0, (total, item) => total + item.totalPrice);
  }

  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }
}
