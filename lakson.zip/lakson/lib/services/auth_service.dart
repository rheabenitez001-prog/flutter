import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../variable.dart';

class AuthService {
  /// Login method for customer authentication
  /// POST /api/customer/login
  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/customer/login'),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({"email": email, "password": password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final token = data["token"];

        // Store token in SharedPreferences
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', token);

        return {
          "success": true,
          "token": token,
          "user": data['user'],
          "message": data['message'] ?? "Login successful",
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          "success": false,
          "message": error['message'] ?? "Login failed",
        };
      }
    } catch (e) {
      return {
        "success": false,
        "message": "An error occurred: ${e.toString()}",
      };
    }
  }

  /// Register method for customer registration
  /// POST /api/customer/register
  static Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String phone,
    required String address,
    required String password,
    required String passwordConfirmation,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/customer/register'),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "name": name,
          "email": email,
          "phone": phone,
          "address": address,
          "password": password,
          "password_confirmation": passwordConfirmation,
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(response.body);

        // Store token if returned
        if (data.containsKey("token")) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('token', data["token"]);
        }

        return {
          "success": true,
          "token": data['token'],
          "user": data['user'],
          "message": data['message'] ?? "Registration successful",
        };
      } else if (response.statusCode == 422) {
        // Validation errors from Laravel
        final data = jsonDecode(response.body);
        return {
          "success": false,
          "errors":
              data['errors'] ??
              {
                "form": ["Validation failed."],
              },
        };
      } else {
        // Other server errors
        final data = jsonDecode(response.body);
        return {
          "success": false,
          "message": data['message'] ?? "Registration failed",
        };
      }
    } catch (e) {
      return {
        "success": false,
        "message": "An error occurred: ${e.toString()}",
      };
    }
  }

  /// Logout method - Clear stored credentials
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('user');
  }
}
