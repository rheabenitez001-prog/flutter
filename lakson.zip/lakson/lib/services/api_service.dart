import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product.dart';
import '../models/order.dart';
import '../variable.dart';

class ApiService {
  /// Fetch all products with Bearer token authentication
  /// GET /api/products
  static Future<List<Product>> getProducts({required String token}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/products'),
        headers: {
          "Accept": "application/json",
          "Authorization": "Bearer $token",
        },
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);

        // Handle both { data: [...] } or raw list [...]
        final List list = decoded is Map ? decoded['data'] : decoded;

        return list
            .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      } else {
        throw Exception('Failed to load products: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching products: ${e.toString()}');
    }
  }

  /// Register a new customer
  /// POST /api/customer/register
  static Future<Map<String, dynamic>> customerRegister({
    required String name,
    required String email,
    required String phone,
    required String address,
    required String password,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/customer/register'),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "name": name,
          "email": email,
          "phone": phone,
          "address": address,
          "password": password,
          "password_confirmation": password,
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return {"success": true, "message": data['message'] ?? 'Registration successful'};
      } else if (response.statusCode == 422) {
        final data = jsonDecode(response.body);
        return {"success": false, "errors": data['errors'] ?? {}};
      } else {
        final data = jsonDecode(response.body);
        return {"success": false, "message": data['message'] ?? 'Registration failed'};
      }
    } catch (e) {
      return {"success": false, "message": 'Error: ${e.toString()}'};
    }
  }

  /// Place an order
  /// POST /api/owner/online-orders
  static Future<Map<String, dynamic>> placeOrder(List<int> productIds) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';

      final order = Order(productIds: productIds, paymentMethod: 'COD');

      final response = await http.post(
        Uri.parse('$baseUrl/owner/online-orders'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode(order.toJson()),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'success': true,
          'message': data['message'] ?? 'Order placed successfully',
        };
      } else {
        final error = jsonDecode(response.body);
        return {
          'success': false,
          'message': error['message'] ?? 'Failed to place order',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Error: ${e.toString()}'};
    }
  }
}
